package com.example.integratedapplication;

public class APIConfig {
   public static String URL_LOGIN = "http://lntifr.azurewebsites.net/api/LANDTApi/LoginAuth?";
   public static String MAPPING_DETAILS = "http://lntifr.azurewebsites.net/api/LANDTApi/GetMappingDetails";
   public static String PICK_LIST_DETAILS = "http://lntifr.azurewebsites.net/api/LANDTApi/GetPickListDetails";
   public static String PICK_LIST_BARCODE_GPSLOCATION = "  http://lntifr.azurewebsites.net/api/LANDTApi/GetPickBarcodeDetails";
}
