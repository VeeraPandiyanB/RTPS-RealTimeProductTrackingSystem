package com.example.integratedapplication;

public class APIConfig {
   public static String URL_LOGIN = "http://lntifr.azurewebsites.net/api/LANDTApi/LoginAuth?";
   public static String MAPPING_DETAILS = "http://lntifr.azurewebsites.net/api/LANDTApi/GetMappingDetails";
   public static String RFID_DETAILS = "//http://lntifr.azurewebsites.net/api/LANDTApi/GetRFIDValue";
   public static String PICK_LIST_DETAILS = "http://lntifr.azurewebsites.net/api/LANDTApi/GetPickListDetails";
   public static String PICK_LIST_BARCODE_GPSLOCATION = "  http://lntifr.azurewebsites.net/api/LANDTApi/GetPickBarcodeDetails";

}
//http://lntifr.azurewebsites.net/api/LANDTApi/GetRFIDValue
//http://lntifr.azurewebsites.net/api/LANDTApi/BindingBarcodeDetails?barCode=2288&RFIDName=a11b22c33d44e55f&gpsLocation=11.025378,76.9758161